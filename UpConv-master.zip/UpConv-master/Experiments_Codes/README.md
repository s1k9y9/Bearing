# Codes

This folder contains the following files:
 <ul>
  <li>Visulaization script</li>
  <li>Azimuthal itegral script</li>
  <li>Spectral regularization scripts: 
   <ul>
    <li>train_spectrum.py</li>
    <li>module_spectrum.py</li>
   </ul> </li>
</ul> 
